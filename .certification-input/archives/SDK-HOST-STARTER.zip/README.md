# Template SDK 2.0.0 host starter

For Sleinity-owned applications. This is host-owned example code, not an SDK UI package.

1. Verify the delivery checksums. Copy its three SDK tarballs into vendor/.
2. Choose npm install or pnpm install, then npm run dev or pnpm dev.
3. Import one exporter 0.6.1 ZIP, or several for a Family. Bring authorized exact fonts when requested.
4. Edit and Reset fields, select Family designs, Save template, then reopen Fresh or Resume.
5. Recovery autosave is this host's 650 ms policy. Correct incomplete inputs before changing work/exporting.
6. PNG requires current renderer readiness; a cleanup failure offers cleanup-only Retry.

Run npm run build (or pnpm build) before integration. Read SDK-QUICKSTART.md, SDK-HOST-IMPLEMENTATION.md, SDK-FEATURES.md and SDK-HOST-LIFECYCLE.md from the parent delivery. No private ZIP/font inputs, registry credential, Studio import or source alias is required. Keep a single manager lockfile in your application.
