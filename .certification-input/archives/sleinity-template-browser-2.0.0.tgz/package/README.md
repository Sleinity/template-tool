# @sleinity/template-browser 2.0.0

Browser V2 import/authoring, native sessions, assets/fonts, persistence/recovery and capture. This is an unpublished fixed-train candidate for Sleinity-owned applications.

Start with [host onboarding](../../docs/sdk/QUICKSTART.md), [the feature guide](../../docs/sdk/FEATURES.md) and [supported entries](../../docs/sdk/API_GUIDE.md). Typical entry: `@sleinity/template-browser/session`. Runtime hosts install all three packages at the same verified version. Core-only consumers need no React.

ZIP admission accepts raw source schema 1.0/exporter 0.6.1 only; canonical packages use schema 2.2. V1 host workflows are retired; required versioned source/evidence contracts remain. No hidden migration or historical-data deletion is provided.

Use public package entries, never Studio, package source or internal entries. Hosts own UI, navigation and disposal; native sessions and the renderer preserve existing resource/readiness authorities. See [ownership](../../docs/sdk/HOST_LIFECYCLE.md), [outcomes](../../docs/sdk/OPERATION_OUTCOMES.md) and [release notes](../../docs/sdk/SDK_2_0_RELEASE_NOTES.md).

Distribution is UNLICENSED and authorized for Sleinity-owned applications only.
